"""SuperMate-LLM-Nodes: local LLM nodes for ComfyUI, backed by llama-cpp-python.

Nodes:
- SuperMateLLMLoader    : load a GGUF (+ optional vision mmproj) from models/LLM
- SuperMateMiniMaxPrompt: brief/image -> MiniMax-H3 structured prompt
                          (modes: 图生视频(可看图) / 文生视频 / 续段)
- SuperMateTextGen      : generic instruct node (dialogue / translate / summarize)
- SuperMateImageToPrompt: image -> prompt (vision), auto-resize to 1024
- SuperMateLLMUnload    : free VRAM/RAM

Type convention: the loader outputs type "LLM_MODEL" (displayed as 模型), a
custom type kept distinct from ComfyUI's diffusion MODEL to avoid mis-wiring.
The llama_cpp backend is imported lazily so the pack registers even when the
wheel is missing; runtime errors surface a clear message instead.
"""

import os
import folder_paths

# ---------------------------------------------------------------------------
# LLM model folder registration (same convention as llama-cpp_vllm)
# ---------------------------------------------------------------------------
_LLM_EXTENSIONS = [".gguf", ".bin", ".pt", ".pth", ".safetensors"]


def _ensure_llm_folder():
    if "LLM" not in folder_paths.folder_names_and_paths:
        folder_paths.folder_names_and_paths["LLM"] = (
            [os.path.join(folder_paths.models_dir, "LLM")], _LLM_EXTENSIONS)


_ensure_llm_folder()

# model cache: (model_name, n_gpu_layers, n_ctx, mmproj) -> Llama instance
_LLM_CACHE = {}


def _strip_thinking(text):
    """Remove the model's thinking/reasoning block, keep only the final answer.

    Qwen3 thinking is wrapped in <|thinking_start|> ... <|thinking_end|>
    (or <thinking> ... </thinking>). If no delimiters found, return as-is
    (never guess-strip, to avoid corrupting real prompt text).

    llama.cpp Qwen3 模板剥离 <think> 块时可能残留 </think> 闭合标签
    （以及模型在 think 块前输出的复述/溢出），此时取 </think> 之后的内容。
    """
    if not text:
        return text
    for start, end in (("<|thinking_start|>", "<|thinking_end|>"),
                       ("<thinking>", "</thinking>"),
                       ("<think>", "</think>")):
        s = text.find(start)
        if s >= 0:
            e = text.find(end, s)
            if e >= 0:
                return text[e + len(end):].strip()
            return text[:s].strip()  # unclosed thinking block -> drop it
    idx = text.rfind("</think>")
    if idx >= 0:
        return text[idx + len("</think>"):].strip()
    return text.strip()


_FINAL_MARKER = "【最终提示词】"


def _final_answer(text):
    """Extract the final answer after the LAST 【最终提示词】 marker.

    The system templates instruct the model to put the final prompt right after
    this marker; anything before it (thinking / analysis / drafts) is discarded.
    Fallbacks when the marker is missing: delimiter-based thinking strip, then
    the last substantial paragraph (the answer usually ends the output).
    """
    if not text:
        return text
    idx = text.rfind(_FINAL_MARKER)
    if idx >= 0:
        return text[idx + len(_FINAL_MARKER):].strip()
    stripped = _strip_thinking(text)
    if stripped != text:
        return stripped
    blocks = [b.strip() for b in text.split("\n\n") if b.strip()]
    if len(blocks) >= 2 and len(blocks[-1]) >= 40:
        return blocks[-1]
    return text.strip()


def _final_answer_h3(text):
    """H3 成品提取：有【最终提示词】标记取标记后；无标记剥离 thinking 后返回全文（不截断）。

    H3 模板要求直接输出整段成品（无【最终提示词】标记、无方括号标题），
    因此不能复用 _final_answer 的"最后一段"回退（会把多镜头输出截断成全局约束）。
    """
    if not text:
        return text
    idx = text.rfind(_FINAL_MARKER)
    if idx >= 0:
        return text[idx + len(_FINAL_MARKER):].strip()
    return _strip_thinking(text)


_NO_THINK = (
    "严禁输出任何思考过程、分析、计划、草稿或检查。"
    "思考会浪费输出长度并导致提示词不完整。"
    "只输出最终内容：最后以一行「【最终提示词】」标记开头，其后为提示词正文，"
    "标记之前不要输出任何内容。"
)

# H3 专用：直接输出成品提示词，禁止方括号标题（H3 不解析【】）
_NO_THINK_H3 = (
    "严禁输出任何思考过程、分析、计划、草稿或检查。"
    "只输出最终内容：直接输出一整段可用的 H3 成品提示词正文，"
    "不要输出任何【】方括号标题、分点编号或解释说明。"
)


# 简化 chat 模板：去掉 GGUF 内置的 "Reasoning effort xhigh" thinking 注入，
# 让 Qwen3.8 直接输出（否则提示词生成会混入大量思考分析）。视觉（MTMD）同样适用。
_SIMPLE_CHAT_TEMPLATE = (
    "{%- for message in messages %}"
    "{{- '<|im_start|>' + message['role'] + '\\n' + message['content'] + '<|im_end|>\\n' }}"
    "{%- endfor %}"
    "{{- '<|im_start|>assistant\\n' }}"
)


def _get_llm(model_name, n_gpu_layers, n_ctx, mmproj_name="None"):
    """Lazily load (or reuse) a Llama instance. mmproj enables vision (MTMD).

    VRAM safety: keeps at most ONE model instance. Changing loader params
    (model / layers / ctx / mmproj) evicts the previously loaded instance
    instead of stacking a second one (each ~12GB on this machine). The vision
    handler (CLIP) is created ONLY when actually loading, so cache hits never
    reload the CLIP or stack it with the old model.
    """
    from llama_cpp import Llama  # imported on first use
    from llama_cpp.llama_chat_format import MTMDChatHandler

    class SuperMateMTMDChatHandler(MTMDChatHandler):
        """MTMD 视觉 handler：默认关闭 Qwen3 模板的 thinking（enable_thinking=False）。

        GGUF 内置 qwen3 模板支持 enable_thinking 变量：为 false 时不注入
        "Reasoning effort" 指令，且 assistant 前缀为空的 <think></think> 块
        （模型直接输出内容、不进入思考）——提示词生成不再混入分析过程。
        """

        def __call__(self, *, llama, messages, **kwargs):
            kwargs.setdefault("enable_thinking", False)
            return super().__call__(llama=llama, messages=messages, **kwargs)

    path = os.path.join(folder_paths.models_dir, "LLM", model_name)
    if not os.path.exists(path):
        raise RuntimeError(f"model file not found: {path}")
    if mmproj_name and mmproj_name != "None":
        mm_path = os.path.join(folder_paths.models_dir, "LLM", mmproj_name)
        if not os.path.exists(mm_path):
            raise RuntimeError(f"mmproj file not found: {mm_path}")
    key = (model_name, n_gpu_layers, n_ctx, mmproj_name)
    llm = _LLM_CACHE.get(key)
    if llm is not None:
        return llm
    # evict any other loaded instance BEFORE creating the new one (VRAM safety)
    for k, old in list(_LLM_CACHE.items()):
        if k != key:
            try:
                old.close()
            except Exception:
                pass
            _LLM_CACHE.pop(k, None)
    chat_handler = None
    if mmproj_name and mmproj_name != "None":
        chat_handler = SuperMateMTMDChatHandler(clip_model_path=mm_path, verbose=False)
    llm = Llama(model_path=path, n_gpu_layers=int(n_gpu_layers),
                n_ctx=int(n_ctx), chat_handler=chat_handler, verbose=False,
                chat_template=_SIMPLE_CHAT_TEMPLATE)
    _LLM_CACHE[key] = llm
    return llm


# 多段输出的模板规则（段落数>1 时生效，插入各 H3 模板）
_H3_MULTI_SEG = (
    "若【段落数】大于1：请输出 N 段独立的 H3 成品提示词，段间用分隔行『——第N段——』；"
    "每段时长=【每段时长】秒，每段内部按镜头分镜（镜头N 时间段+景别+机位）；"
    "人物外观、服装、场景、打光、氛围全程与第一段完全一致（<Subject 1>/<Picture N> 引用保持不变）；"
    "台词按剧情推进合理分配到各段；每段结尾写明『段尾状态：...』（动作/表情/场景），下一段开头承接该状态；\n"
)


# ---------------------------------------------------------------------------
# H3 prompt templates (built from the h3-prompt-writing methodology)
# ---------------------------------------------------------------------------
_H3_SYSTEM_I2V = (
    "你是顶级专业影视导演级 MiniMax H3 提示词生成助手。用户的输入是【内容要点】和可选【额外约束】。"
    "请输出一段可直接导入 MiniMax H3 图生视频的完整成品提示词，要求：\n"
    "1. 开头明确画风/质感与核心场景设定；若后续接参考图，则锁定与参考图一致（人物身份、外观、服装、场景逐项对齐）；\n"
    "2. 分镜结构：明确总时长，每个镜头写『镜头N（时间段），景别，机位：...』（景别用全景/中景/近景/特写等，机位写清角度与运动），动作过程按时间推进、自然有逻辑；\n"
    "3. 每个镜头之间写『转场：...』（硬切/叠化/匹配转场/推拉转场等），转场只写在镜头之间、不写进镜头内部；\n"
    "4. 有对话写 (S1) 神情动作，说道：<d>[Chinese]台词内容</d>，匹配画面神情与氛围；无对话写『无对白』并写清环境音/音效；\n"
    "5. 结尾写全局约束：打光、画质、无字幕、无水印、不出现多余文字（书本/包装等文字内容为模糊纹理，无可读清晰字符）、无肢体错位/穿模/五官漂移；\n"
    "6. 输出硬性标准：一整段连贯文本，无【】方括号标题、无分点、无解释、无思考过程，直接输出成品提示词；\n"
    "7. " + _H3_MULTI_SEG + "8. " + _NO_THINK_H3
)

_H3_SYSTEM_T2V = (
    "你是顶级专业影视导演级 MiniMax H3 提示词生成助手。用户的输入是【内容要点】和可选【额外约束】。"
    "请输出一段可直接导入 MiniMax H3 文生视频的完整成品提示词，要求：\n"
    "1. 开头明确画风/质感与核心场景设定；\n"
    "2. 分镜结构：明确总时长，每个镜头写『镜头N（时间段），景别，机位：...』，动作自然有逻辑；\n"
    "3. 每个镜头之间写『转场：...』（硬切/叠化/匹配/推拉等）；\n"
    "4. 有对话写 (S1) 神情动作，说道：<d>[Chinese]台词内容</d>；无对话写『无对白』并写清环境音/音效；\n"
    "5. 结尾写全局约束：打光、画质、无字幕、无水印、不出现多余文字（书本/包装等文字内容为模糊纹理，无可读清晰字符）、无肢体错位/穿模/五官漂移；\n"
    "6. 输出硬性标准：一整段连贯文本，无【】方括号标题、无分点、无解释、无思考过程，直接输出成品提示词；\n"
    "7. " + _H3_MULTI_SEG + "8. " + _NO_THINK_H3
)

_H3_SYSTEM_CONT = (
    "你是顶级专业影视导演级 MiniMax H3 提示词生成助手，负责生成『续段』提示词。用户会提供【上一段内容】和【本段要点】。"
    "请输出本段的完整成品提示词，要求：\n"
    "1. 开头用『承接上一段最后“动作A”的状态』明确衔接（上一段的结尾动作作为本段起点）；\n"
    "2. 人物外观、服装、场景、打光、机位必须与上一段完全一致，逐条写清；\n"
    "3. 分镜结构：明确本段总时长，每个镜头写『镜头N（时间段），景别，机位：...』；\n"
    "4. 每个镜头之间写『转场：...』；\n"
    "5. 对话延续上一段讲稿的语气与音色，格式 (S1) 神情动作，说道：<d>[Chinese]台词内容</d>；\n"
    "6. 结尾写全局约束：无外观漂移、无字幕、不出现多余文字、无穿模/五官漂移；\n"
    "7. 输出硬性标准：一整段连贯文本，无【】方括号标题、无分点、无解释、无思考过程；\n"
    "8. " + _H3_MULTI_SEG + "9. " + _NO_THINK_H3
)


class SuperMateLLMLoader:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "model": (folder_paths.get_filename_list("LLM"),),
                "n_gpu_layers": ("INT", {"default": -1, "min": -1, "max": 200,
                                         "tooltip": "-1 = 全部层进 GPU"}),
                "n_ctx": ("INT", {"default": 8192, "min": 256, "max": 131072,
                                  "tooltip": "视觉(图片反推)建议 ≥8192，图像 token 较多"}),
            },
            "optional": {
                "mmproj": (["None"] + folder_paths.get_filename_list("LLM"),
                           {"default": "None",
                            "tooltip": "视觉投影模型（如 Qwen3.8-27B-mmproj-BF16.gguf），选上即可看图"}),
            }
        }

    RETURN_TYPES = ("LLM_MODEL",)
    RETURN_NAMES = ("模型",)
    FUNCTION = "load"
    CATEGORY = "SuperMate/LLM"

    def load(self, model, n_gpu_layers, n_ctx, mmproj="None"):
        llm = _get_llm(model, n_gpu_layers, n_ctx, mmproj)
        return (llm,)


class SuperMateTextGen:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "模型": ("LLM_MODEL",),
                "system_prompt": ("STRING", {"multiline": True, "default": "你是一个有帮助的助手。"}),
                "text": ("STRING", {"multiline": True, "default": ""}),
                "temperature": ("FLOAT", {"default": 0.7, "min": 0.0, "max": 2.0, "step": 0.05}),
                "文本长度": ("INT", {"default": 1024, "min": 16, "max": 8192}),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("text",)
    FUNCTION = "generate"
    CATEGORY = "SuperMate/LLM"

    def generate(self, 模型, system_prompt, text, temperature, 文本长度):
        out = 模型.create_chat_completion(
            messages=[{"role": "system", "content": system_prompt + "\n\n" + _NO_THINK},
                      {"role": "user", "content": text}],
            temperature=float(temperature), max_tokens=int(文本长度))
        return (_final_answer(out["choices"][0]["message"]["content"]),)


def _aspect_ratio_str(w, h, preset):
    """Return display ratio as 'W:H'. preset 非「保持原图」时用预设，否则用图片原生比例。"""
    if preset and preset != "保持原图":
        return preset
    import math
    g = math.gcd(w, h) or 1
    return f"{w // g}:{h // g}"


def _parse_duration(需求, default):
    """从需求文本解析时长（优先），如 '5秒'/'5s'/'10s的vlog'；无则用参数默认。"""
    import re
    if 需求:
        m = re.search(r"(\d{1,3})\s*秒|(\d{1,3})\s*s", 需求)
        if m:
            v = int(m.group(1) or m.group(2))
            if 5 <= v <= 120:
                return v
    return int(default)


def _seg_note(段落数, 时长):
    """段落数>1 时返回段落说明（追加到 user 消息）。"""
    if 段落数 and 段落数 > 1:
        return f"\n【段落数】{int(段落数)}段，每段{int(时长)}秒——请输出{int(段落数)}段独立提示词，段间用『——第N段——』分隔"
    return ""


class SuperMateImageToPrompt:
    """图片反推：把 ComfyUI IMAGE 转成视觉提示词（需 Loader 配 mmproj）。

    输入图片自动缩放（默认 1024 长边）——实测原图 466s -> 35s（约 13 倍提速）。
    输出最终完整提示词；显示比例可预设（默认保持图片原生比例）并写入输出。
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "模型": ("LLM_MODEL",),
                "IMAGE": ("IMAGE",),
                "描述要求": ("STRING", {"multiline": True, "default": "请用中文详细描述这张图片：主体人物、服装外貌、场景环境、画风质感、构图、光线色调。描述要具体、适合作为AI绘画/视频生成的提示词。", "tooltip": "反推提示词的模板要求"}),
                "显示比例": (["保持原图", "16:9", "4:3", "3:4", "9:16", "1:1"], {"default": "保持原图",
                                                                                  "tooltip": "输出中注明的画面比例；保持原图=用图片自身比例"}),
                "文本长度": ("INT", {"default": 1024, "min": 32, "max": 4096}),
                "最大边长": ("INT", {"default": 1024, "min": 256, "max": 2048,
                                     "tooltip": "输入图片超过此边长时先缩小（实测原图466s→35s，约13倍提速）；模型训练分辨率≈1024"}),
            }
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("text",)
    FUNCTION = "generate"
    CATEGORY = "SuperMate/LLM"

    def generate(self, 模型, IMAGE, 描述要求, 显示比例, 文本长度, 最大边长=1024):
        import base64, io
        from PIL import Image as PILImage
        import torch
        img = IMAGE[0]  # H,W,C float 0-1
        if torch.is_tensor(img):
            img = img.detach().cpu().clamp(0, 1).mul(255).byte().numpy()
        pil = PILImage.fromarray(img)
        ratio = _aspect_ratio_str(pil.size[0], pil.size[1], 显示比例)
        if 最大边长 and 最大边长 > 0:
            w, h = pil.size
            scale = int(最大边长) / max(w, h)
            if scale < 1:
                pil = pil.resize((round(w * scale), round(h * scale)))
        buf = io.BytesIO()
        pil.save(buf, format="PNG")
        b64 = base64.b64encode(buf.getvalue()).decode()
        prompt_text = f"{描述要求}\n（输出末尾注明画面比例：{ratio}）"
        out = 模型.create_chat_completion(
            messages=[{"role": "system", "content": _NO_THINK},
                      {"role": "user", "content": [
                          {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                          {"type": "text", "text": prompt_text},
                      ]}],
            temperature=0.4, max_tokens=int(文本长度))
        return (_final_answer(out["choices"][0]["message"]["content"]),)


_VISION_DESCRIBE = (
    "请用中文详细描述这张图片：主体、场景环境、画风质感、构图、光线色调、"
    "人物外貌与服装（如有）。作为AI视频生成的参考信息。\n" + _NO_THINK_H3
)

_H3_WRITE_SCENE = (
    "你是顶级专业影视导演级 MiniMax H3 提示词生成助手。用户提供【参考图组】（<Picture 1> 为主参考，"
    "<Picture 2>/<Picture 3> 等为补充：背景/灯光/质感参考）和一段简单需求。"
    "参考图组用于提供【场景/画风/构图/氛围】基础：主图定基调，补充图细化背景/光线等，综合所有参考图的信息。"
    "请基于【图片描述】与【用户需求】，输出一段可直接导入 MiniMax H3 图生视频的完整成品提示词，要求：\n"
    "1. 开头写明画风/质感与参考图组的关系：整体场景布局、环境光影、色调构图、氛围质感参照 <Picture 1> 及补充参考图；\n"
    "2. 分镜结构：明确总时长，每个镜头写『镜头N（时间段），景别，机位：...』，动作自然有逻辑；\n"
    "3. 每个镜头之间写『转场：...』（硬切/叠化/匹配/推拉等），转场只写在镜头之间、不写进镜头内部；\n"
    "4. 有对话写 (S1) 神情动作，说道：<d>[Chinese]台词内容</d>；无对话写『无对白』并写清环境音/音效；\n"
    "5. 结尾写全局约束：打光、画质、无字幕、无水印、不出现多余文字（书本/包装等文字内容为模糊纹理，无可读清晰字符）、无肢体错位/穿模/五官漂移；\n"
    "6. 输出硬性标准：一整段连贯文本，无【】方括号标题、无分点、无解释、无思考过程；<Picture N> 标签仅在引用参考图时使用，不虚构标签；\n"
    "7. " + _H3_MULTI_SEG + "8. " + _NO_THINK_H3
)

_H3_WRITE_CHAR = (
    "你是顶级专业影视导演级 MiniMax H3 提示词生成助手。用户提供【人物参考图组】（<Picture 1> 主人物图，"
    "<Picture 2> 人物其他角度，<Picture 3>/<Picture 4> 背景/灯光参考）和一段简单需求。\n"
    "参考图组用于提取【人物身份】与【氛围基础】：多张人物图相互印证取共同特征，背景/灯光图提供场景与光环境参考。\n"
    "请基于【图片描述】与【用户需求】，输出一段可直接导入 MiniMax H3 图生视频的完整成品提示词，要求：\n"
    "1. 人物锁定开头：<Subject 1>人物样貌、五官、发型、服饰、体态、气质完全参照<Picture 1>（多张人物图取共同特征），"
    "全程保持人物特征稳定一致，无特征偏移、无面部崩坏；\n"
    "2. 场景/氛围：整体场景布局、环境光影、色调构图、氛围质感参照背景/灯光参考图；"
    "人物在全新场景中自然表演，画面绝不出现参考图本身（无相框/缩略图/拼贴/画中画/加载框）；\n"
    "3. 分镜结构：明确总时长，每个镜头写『镜头N（时间段），景别，机位：...』，写清动作与表演过程；\n"
    "4. 每个镜头之间写『转场：...』；\n"
    "5. 有对话写 (S1) 神情动作，说道：<d>[Chinese]台词内容</d>；无对话写『无对白』并写清环境音/音效；\n"
    "6. 结尾写全局约束：打光、画质、无字幕、无水印、不出现多余文字（书本/包装等文字内容为模糊纹理，无可读清晰字符）、"
    "无参考图出现、无肢体错位/穿模/五官漂移；\n"
    "7. 输出硬性标准：一整段连贯文本，无【】方括号标题、无分点、无解释、无思考过程；<Picture N> 标签仅在引用参考图时使用，不虚构标签；\n"
    "8. " + _H3_MULTI_SEG + "9. " + _NO_THINK_H3
)


class SuperMateMiniMaxPrompt:
    """MiniMax 提示词增强：一张图 / 一句话 → 可直接用于 MiniMax H3 的完整提示词。

    排版说明（参数顺序即界面顺序）：
      required: 模型 → 模式 → 需求 → 参考图用途 → 显示比例 → 时长 → 最大边长 → 文本长度
      optional: 图片 → 额外约束 → 上一段内容

    用法：
      - 接图片 + 模式=图生视频：先视觉分析图片，再按「场景参考 / 人物参考」写 H3 提示词；
      - 不接图片：按 文生视频 / 图生视频 / 续段 三模板走纯文本；
      - 参考图用途、显示比例、最大边长 仅「图生视频 + 接图」时生效，其余模式自动忽略。

    需要多张参考图（最多 5 张）或视频抽帧 → 用 SuperMateMiniMaxPromptMulti。
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "模型": ("LLM_MODEL",),
                "模式": (["图生视频", "文生视频", "续段"], {"default": "图生视频",
                                                        "tooltip": "图生视频=接图看图写；文生视频=纯文本；续段=接上一段结尾写下一段"}),
                "需求": ("STRING", {"multiline": True, "default": "根据图片内容，为我设计一段vlog视频",
                                    "placeholder": "例：根据图片设计一段vlog / 让人物在海边讲一个笑话 / 描述一个场景…"}),
                "参考图用途": (["场景参考", "人物参考"], {"default": "场景参考",
                                                         "tooltip": "仅「图生视频 + 接了图片」时生效：场景参考=沿用参考图场景/画风展开；人物参考=只取人物长相，画面不出现参考图原图"}),
                "显示比例": (["保持原图", "16:9", "4:3", "3:4", "9:16", "1:1"], {"default": "保持原图",
                                                                                  "tooltip": "提示词中注明的画面比例；保持原图=用图片自身比例（无图时忽略）"}),
                "时长": ("INT", {"default": 10, "min": 5, "max": 30,
                                 "tooltip": "视频总时长（秒），分镜时间轴需覆盖全片"}),
                "最大边长": ("INT", {"default": 1024, "min": 256, "max": 2048,
                                     "tooltip": "图片超过此边长先缩小（提速）；仅「图生视频 + 接图」时生效"}),
                "文本长度": ("INT", {"default": 2500, "min": 256, "max": 8192,
                                       "tooltip": "输出最大长度；留足余量给正文"}),
                "段落数": ("INT", {"default": 1, "min": 1, "max": 5,
                                   "tooltip": "输出段落数：1=单段；>1 输出多段连续提示词（每段时长=时长参数，人物/场景全程一致，台词按段分配，段间链式衔接，用『——第N段——』分隔）"}),
            },
            "optional": {
                "图片": ("IMAGE",
                         {"tooltip": "仅「图生视频」模式使用；未接自动走纯文本"}),
                "额外约束": ("STRING", {"multiline": True, "default": ""}),
                "上一段内容": ("STRING", {"multiline": True, "default": "",
                                          "tooltip": "仅「续段」模式需要：上一段提示词的结尾/动作"}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("text",)
    FUNCTION = "generate"
    CATEGORY = "SuperMate/LLM"

    def generate(self, 模型, 模式, 需求, 参考图用途, 显示比例, 时长,
                 最大边长=1024, 文本长度=2500, 段落数=1, 图片=None, 额外约束="", 上一段内容=""):
        时长 = _parse_duration(需求, 时长)
        has_img = 图片 is not None
        if not (需求 or "").strip():
            if has_img and 模式 == "图生视频":
                需求 = "根据图片内容，为我设计一段vlog视频"
            else:
                需求 = "一位年轻女子在春日公园的长椅上读书，阳光透过树叶洒落，画面宁静治愈"

        # 看图分支：仅「图生视频 + 接了图片」
        if has_img and 模式 == "图生视频":
            return self._vision_h3(模型, 图片, 参考图用途, 需求, 显示比例, 时长,
                                   最大边长, 文本长度, 段落数, 额外约束)

        # 纯文本分支（无图，或模式≠图生视频）
        if 模式 == "续段":
            system = _H3_SYSTEM_CONT
            user = f"【上一段内容】\n{上一段内容}\n\n【本段要点】\n{需求}\n\n【总时长】{int(时长)}秒"
        elif 模式 == "文生视频":
            system = _H3_SYSTEM_T2V
            user = f"【内容要点】\n{需求}\n\n【总时长】{int(时长)}秒"
        else:  # 图生视频（无图）
            system = _H3_SYSTEM_I2V
            user = f"【内容要点】\n{需求}\n\n【总时长】{int(时长)}秒"
        user += _seg_note(段落数, 时长)
        if 额外约束:
            user += f"\n\n【额外约束】\n{额外约束}"
        out = 模型.create_chat_completion(
            messages=[{"role": "system", "content": system},
                      {"role": "user", "content": user}],
            temperature=0.6, max_tokens=int(文本长度))
        return (_final_answer_h3(out["choices"][0]["message"]["content"]),)

    def _vision_h3(self, 模型, 图片, 参考图用途, 需求, 显示比例, 时长,
                   最大边长, 文本长度, 段落数=1, 额外约束=""):
        import base64, io
        from PIL import Image as PILImage
        import torch
        img = 图片[0]
        if torch.is_tensor(img):
            img = img.detach().cpu().clamp(0, 1).mul(255).byte().numpy()
        pil = PILImage.fromarray(img)
        ratio = _aspect_ratio_str(pil.size[0], pil.size[1], 显示比例)
        if 最大边长 and 最大边长 > 0:
            w, h = pil.size
            scale = int(最大边长) / max(w, h)
            if scale < 1:
                pil = pil.resize((round(w * scale), round(h * scale)))
        buf = io.BytesIO()
        pil.save(buf, format="PNG")
        b64 = base64.b64encode(buf.getvalue()).decode()

        # 第一步：视觉描述
        desc = 模型.create_chat_completion(
            messages=[{"role": "user", "content": [
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
                {"type": "text", "text": _VISION_DESCRIBE},
            ]}],
            temperature=0.3, max_tokens=800)
        desc_text = _final_answer_h3(desc["choices"][0]["message"]["content"])

        # 第二步：按参考图用途写 H3 提示词
        system = _H3_WRITE_CHAR if 参考图用途 == "人物参考" else _H3_WRITE_SCENE
        user = (f"【图片描述】\n{desc_text}\n\n【用户需求】\n{需求}\n\n"
                f"【总时长】{int(时长)}秒\n【画面比例】{ratio}（请在提示词中注明画面比例：{ratio}）")
        user += _seg_note(段落数, 时长)
        if 额外约束:
            user += f"\n\n【额外约束】\n{额外约束}"
        out = 模型.create_chat_completion(
            messages=[{"role": "system", "content": system},
                      {"role": "user", "content": user}],
            temperature=0.6, max_tokens=int(文本长度))
        return (_final_answer_h3(out["choices"][0]["message"]["content"]),)


class SuperMateMiniMaxPromptMulti:
    """MiniMax 提示词增强（多图版）：最多 5 张参考图 + 视频抽帧 → 可直接用于 MiniMax H3 的完整提示词。

    排版说明（参数顺序即界面顺序）：
      required: 模型 → 模式 → 需求 → 参考图用途 → 显示比例 → 时长 → 最大边长 → 文本长度
      optional: 图片(主参考) → 图片2~5(补充参考) → 视频文件(自动抽帧) → 额外约束 → 上一段内容

    多图用法（最多 5 张，接几张用几张，未接端口自动忽略）：
      - 图片1：主参考（人物/场景主体）
      - 图片2~5：补充参考（人物另一角度 / 背景 / 灯光参考等）
      - 视频文件：填本地视频路径，自动用 ffmpeg 抽 4 帧并入参考图组（Qwen3.8 多图理解）

    用法：
      - 接图/视频 + 模式=图生视频：先多图综合视觉分析，再按「场景参考 / 人物参考」写 H3 提示词；
      - 不接图：按 文生视频 / 图生视频 / 续段 三模板走纯文本；
      - 参考图用途、显示比例、最大边长 仅「图生视频 + 接图」时生效，其余模式自动忽略。

    单图需求请用 SuperMateMiniMaxPrompt（本节点为多图增强版）。
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "模型": ("LLM_MODEL",),
                "模式": (["图生视频", "文生视频", "续段"], {"default": "图生视频",
                                                        "tooltip": "图生视频=接图看图写；文生视频=纯文本；续段=接上一段结尾写下一段"}),
                "需求": ("STRING", {"multiline": True, "default": "根据图片内容，为我设计一段vlog视频",
                                    "placeholder": "例：根据图片设计一段vlog / 让人物在海边讲一个笑话 / 描述一个场景…"}),
                "参考图用途": (["场景参考", "人物参考"], {"default": "场景参考",
                                                         "tooltip": "仅「图生视频 + 接了图片」时生效：场景参考=沿用参考图场景/画风展开；人物参考=只取人物长相，画面不出现参考图原图"}),
                "显示比例": (["保持原图", "16:9", "4:3", "3:4", "9:16", "1:1"], {"default": "保持原图",
                                                                                  "tooltip": "提示词中注明的画面比例；保持原图=用图片自身比例（无图时忽略）"}),
                "时长": ("INT", {"default": 10, "min": 5, "max": 30,
                                 "tooltip": "视频总时长（秒），分镜时间轴需覆盖全片"}),
                "最大边长": ("INT", {"default": 1024, "min": 256, "max": 2048,
                                     "tooltip": "图片超过此边长先缩小（提速）；仅「图生视频 + 接图」时生效"}),
                "文本长度": ("INT", {"default": 2500, "min": 256, "max": 8192,
                                       "tooltip": "输出最大长度；留足余量给正文"}),
                "段落数": ("INT", {"default": 1, "min": 1, "max": 5,
                                   "tooltip": "输出段落数：1=单段；>1 输出多段连续提示词（每段时长=时长参数，人物/场景全程一致，台词按段分配，段间链式衔接，用『——第N段——』分隔）"}),
            },
            "optional": {
                "图片": ("IMAGE",
                         {"tooltip": "主参考图（人物/场景主体）；仅「图生视频」模式使用"}),
                "图片2": ("IMAGE",
                          {"tooltip": "补充参考图2（如人物另一角度）；未接自动忽略"}),
                "图片3": ("IMAGE",
                          {"tooltip": "补充参考图3（如背景/环境）；未接自动忽略"}),
                "图片4": ("IMAGE",
                          {"tooltip": "补充参考图4（如灯光/质感参考）；未接自动忽略"}),
                "图片5": ("IMAGE",
                          {"tooltip": "补充参考图5；未接自动忽略"}),
                "视频文件": ("STRING", {"default": "",
                                        "tooltip": "本地视频路径（mp4/webm 等）；填了自动 ffmpeg 抽 4 帧并入参考图组（需 ffmpeg 在 PATH）"}),
                "额外约束": ("STRING", {"multiline": True, "default": ""}),
                "上一段内容": ("STRING", {"multiline": True, "default": "",
                                          "tooltip": "仅「续段」模式需要：上一段提示词的结尾/动作"}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("text",)
    FUNCTION = "generate"
    CATEGORY = "SuperMate/LLM"

    def generate(self, 模型, 模式, 需求, 参考图用途, 显示比例, 时长,
                 最大边长=1024, 文本长度=2500, 段落数=1, 图片=None, 图片2=None, 图片3=None,
                 图片4=None, 图片5=None, 视频文件="", 额外约束="", 上一段内容=""):
        时长 = _parse_duration(需求, 时长)
        # 收集所有参考图（按槽位顺序，跳过未连接的 None）
        ref_images = []
        for name, img in (("图片1", 图片), ("图片2", 图片2), ("图片3", 图片3),
                          ("图片4", 图片4), ("图片5", 图片5)):
            if img is not None:
                ref_images.append((name, img))

        # 视频抽帧并入参考图组（有路径时）
        video_frames = self._extract_video_frames(视频文件) if (视频文件 or "").strip() else []

        has_img = len(ref_images) > 0
        if not (需求 or "").strip():
            if (has_img or video_frames) and 模式 == "图生视频":
                需求 = "根据图片内容，为我设计一段vlog视频"
            else:
                需求 = "一位年轻女子在春日公园的长椅上读书，阳光透过树叶洒落，画面宁静治愈"

        # 看图分支：仅「图生视频 + 接了图片或视频」
        if (has_img or video_frames) and 模式 == "图生视频":
            return self._vision_h3(模型, ref_images, video_frames, 参考图用途, 需求,
                                   显示比例, 时长, 最大边长, 文本长度, 段落数, 额外约束)

        # 纯文本分支（无图，或模式≠图生视频）
        if 模式 == "续段":
            system = _H3_SYSTEM_CONT
            user = f"【上一段内容】\n{上一段内容}\n\n【本段要点】\n{需求}\n\n【总时长】{int(时长)}秒"
        elif 模式 == "文生视频":
            system = _H3_SYSTEM_T2V
            user = f"【内容要点】\n{需求}\n\n【总时长】{int(时长)}秒"
        else:  # 图生视频（无图）
            system = _H3_SYSTEM_I2V
            user = f"【内容要点】\n{需求}\n\n【总时长】{int(时长)}秒"
        user += _seg_note(段落数, 时长)
        if 额外约束:
            user += f"\n\n【额外约束】\n{额外约束}"
        out = 模型.create_chat_completion(
            messages=[{"role": "system", "content": system},
                      {"role": "user", "content": user}],
            temperature=0.6, max_tokens=int(文本长度))
        return (_final_answer_h3(out["choices"][0]["message"]["content"]),)

    def _extract_video_frames(self, video_path, n_frames=4):
        """ffmpeg 等间隔抽帧：视频路径 → 最多 n_frames 张 PIL 图。失败返回 []。"""
        if not (video_path or "").strip():
            return []
        import subprocess, tempfile, os, shutil
        if not os.path.exists(video_path):
            print(f"[SuperMate MiniMaxPrompt] 视频文件不存在: {video_path}")
            return []
        tmpdir = tempfile.mkdtemp(prefix="sm_llm_vid_")
        try:
            cmd = ["ffmpeg", "-y", "-i", video_path,
                   "-vf", f"fps={n_frames}/1", "-frames:v", str(n_frames),
                   "-q:v", "2", os.path.join(tmpdir, "f%02d.jpg")]
            subprocess.run(cmd, capture_output=True, timeout=180)
            from PIL import Image
            frames = []
            for i in range(n_frames):
                p = os.path.join(tmpdir, f"f{i + 1:02d}.jpg")
                if os.path.exists(p):
                    frames.append(Image.open(p).convert("RGB"))
            return frames
        except Exception as e:
            print(f"[SuperMate MiniMaxPrompt] 视频抽帧失败: {e}")
            return []
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _vision_h3(self, 模型, ref_images, video_frames, 参考图用途, 需求, 显示比例, 时长,
                   最大边长, 文本长度, 段落数=1, 额外约束=""):
        import base64, io
        from PIL import Image as PILImage
        import torch

        def tensor_to_pil(img):
            if torch.is_tensor(img):
                img = img[0]  # B,H,W,C → H,W,C（取 batch 第一帧）
                img = img.detach().cpu().clamp(0, 1).mul(255).byte().numpy()
            return PILImage.fromarray(img)

        def pil_to_b64(pil):
            if 最大边长 and 最大边长 > 0:
                w, h = pil.size
                scale = int(最大边长) / max(w, h)
                if scale < 1:
                    pil = pil.resize((round(w * scale), round(h * scale)))
            buf = io.BytesIO()
            pil.save(buf, format="PNG")
            return base64.b64encode(buf.getvalue()).decode()

        # 组装多模态 content（全部参考图 + 视频帧）+ 标签
        content = []
        img_labels = []
        for name, img in ref_images:
            content.append({"type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{pil_to_b64(tensor_to_pil(img))}"}})
            img_labels.append(name)
        for i, frame in enumerate(video_frames, 1):
            content.append({"type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{pil_to_b64(frame)}"}})
            img_labels.append(f"视频帧{i}")

        # 显示比例：优先主参考图（图片1），其次视频帧
        ratio = "16:9"
        if ref_images:
            fp = tensor_to_pil(ref_images[0][1])
            ratio = _aspect_ratio_str(fp.size[0], fp.size[1], 显示比例)
        elif video_frames:
            ratio = _aspect_ratio_str(video_frames[0].size[0], video_frames[0].size[1], 显示比例)

        n_img = len(img_labels)
        label_str = "、".join(img_labels)

        # 第一步：多图综合视觉描述
        desc_prompt = (
            f"以下共 {n_img} 张参考图（顺序：{label_str}）。"
            f"请逐一用中文详细描述每张图：主体、场景环境、画风质感、构图、光线色调、"
            f"人物外貌与服装（如有），并说明各图之间的关系。\n" + _NO_THINK_H3
        )
        desc = 模型.create_chat_completion(
            messages=[{"role": "user", "content": content + [{"type": "text", "text": desc_prompt}]}],
            temperature=0.3, max_tokens=min(1600, int(文本长度)))
        desc_text = _final_answer_h3(desc["choices"][0]["message"]["content"])

        # 第二步：按参考图用途写 H3 提示词
        system = _H3_WRITE_CHAR if 参考图用途 == "人物参考" else _H3_WRITE_SCENE
        user = (f"【图片描述】\n{desc_text}\n\n【用户需求】\n{需求}\n\n"
                f"【总时长】{int(时长)}秒\n【画面比例】{ratio}（请在提示词中注明画面比例：{ratio}）")
        user += _seg_note(段落数, 时长)
        if 额外约束:
            user += f"\n\n【额外约束】\n{额外约束}"
        out = 模型.create_chat_completion(
            messages=[{"role": "system", "content": system},
                      {"role": "user", "content": user}],
            temperature=0.6, max_tokens=int(文本长度))
        return (_final_answer_h3(out["choices"][0]["message"]["content"]),)


class AnyType(str):
    """ComfyUI 通配类型：任意类型的输出都可以连接到本输入（同 MemoryCleaner）。"""
    def __ne__(self, __value: object) -> bool:
        return False


any_type = AnyType("*")


class SuperMateLLMUnload:
    """卸载已加载的 LLM 模型，释放显存/内存。

    用法（两种）：
      1. 接在工作流链尾（推荐）：把 MiniMaxPrompt / ImageToPrompt / TextGen 的
         text 输出接到本节点「输入」——LLM 任务执行完立即卸载，腾出显存给后续
         H3 视频等重负载工作流（避免先跑反推、再跑 H3 时爆显存）；
      2. 单独放在目标工作流中（不接输入）：执行该工作流时会先执行本节点，
         卸载残留 LLM 再继续生成。
    输入为任意类型，原样透传，不改变数据。
    """

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {},
            "optional": {
                "输入": (any_type, {
                    "tooltip": "任意输入：接到工作流链尾（如提示词节点的 text 输出）作为执行触发，原样透传；留空=独立使用，执行本工作流时先卸载再继续",
                }),
            }
        }

    RETURN_TYPES = (any_type,)
    RETURN_NAMES = ("输出",)
    FUNCTION = "unload"
    CATEGORY = "SuperMate/LLM"
    OUTPUT_NODE = True

    def unload(self, 输入=None):
        global _LLM_CACHE
        n = len(_LLM_CACHE)
        for llm in _LLM_CACHE.values():
            try:
                llm.close()
            except Exception as e:
                print(f"[SuperMate LLM Unload] close 失败: {e}")
        _LLM_CACHE.clear()
        # 释放 ComfyUI 自身 torch 缓存（llama.cpp 显存 close 后已释放，这里兜底）
        try:
            import gc
            gc.collect()
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass
        print(f"[SuperMate LLM Unload] 已卸载 {n} 个模型实例，显存缓存已清空")
        return (输入,)


NODE_CLASS_MAPPINGS = {
    "SuperMateLLMLoader": SuperMateLLMLoader,
    "SuperMateMiniMaxPrompt": SuperMateMiniMaxPrompt,
    "SuperMateMiniMaxPromptMulti": SuperMateMiniMaxPromptMulti,
    "SuperMateTextGen": SuperMateTextGen,
    "SuperMateImageToPrompt": SuperMateImageToPrompt,
    "SuperMateLLMUnload": SuperMateLLMUnload,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "SuperMateLLMLoader": "SuperMate LLM Loader",
    "SuperMateMiniMaxPrompt": "MiniMax 提示词增强",
    "SuperMateMiniMaxPromptMulti": "MiniMax 提示词增强（多图）",
    "SuperMateTextGen": "SuperMate Text Gen",
    "SuperMateImageToPrompt": "SuperMate 图片反推",
    "SuperMateLLMUnload": "SuperMate LLM Unload",
}
